#!/usr/bin/env Rscript
# -*- coding: utf-8 -*-


###!/usr/bin/env Rscript
##args = commandArgs(trailingOnly=TRUE)

######################################################################################################################################################

# Run the taxonomy analysis of your metabarcoding data, after running it through DADA2 and BLASTN:

######################################################################################################################################################
#remove everything in the working environment, without a warning!!
rm(list=ls())

# Rlibpath <- "/groups/hologenomics/phq599/data/R_packages_for_Rv4_0_2"
# Sys.setenv(R_LIBS_USER=Rlibpath)
# .libPaths(Rlibpath)

# #install the required package if needed:
# #install packages
# #get taxize package
# if(!require(taxize)){
#   install.packages("taxize")
# }
# library(taxize)
wd00 <- "/home/hal9000/Documents/shrfldubuntu18/ebiodiv"
setwd(wd00)
getwd()
#define input file names - i.e. the output you got from the blast result
#the first is the unfiltered BLAST hits
inputfilenm1="part04_blast_blibnumber.results.01.txt"
inputfilenm1="part04_blast_b009.results.01.txt"
# the secomnd file is the prefiltered BLAST hits from which the more untrusted species have been removed
inputfilenm2="part05_blast_blibnumber.results.02.txt"
inputfilenm2="part05_blast_b009.results.02.txt"

#define output file names 
outputfilenm1="part06_my_classified_otus_blibnumber.01.unfilt_BLAST_results.txt"
outputfilenm2="part06_my_classified_otus_blibnumber.02.filt_BLAST_results.txt"

outputfilenm1="part06_my_classified_otus_b009.01.unfilt_BLAST_results.txt"
outputfilenm2="part06_my_classified_otus_b009.02.filt_BLAST_results.txt"

# df_iofn <- as.data.frame(cbind(
#             c(1,2),
#             c(inputfilenm1,inputfilenm2),
#             c(outputfilenm1,outputfilenm2)))
# colnames(df_iofn) <- c("flno",
#                        "inf",
#                        "ouf")

# #install packages
# #get taxize package
# if(!require(taxize)){
#   install.packages("taxize")
# }
# library(taxize)

# ########################################################################################################################
# # part06 - 01 start - run my_txonomyB on non-filtered BLAST hits
# ########################################################################################################################
# 
# # read the completed blast results into a table
# # set 'fill=T' to TRUE to make sure that tables with irregular number of columns are read in as well
# IDtable <- read.csv(file = inputfilenm1, sep='\t', header=F, as.is=TRUE, fill=T)
# # add header information, so the table is all nice and pretty
# names(IDtable) <- c("qseqid","sseqid","pident","length","mismatch","gapopen","qstart","qend","sstart","send","evalue","bitscore","qlen","qcovs","sgi","sseq","ssciname","staxid")
# # extract only those rows where the qcovs score is 100
# IDtable <- IDtable[IDtable$qcovs==100,]



# Sys.setenv(R_LIBS_USER="~/myRlib")
# .libPaths("~/myRlib")
# 
# print(args[1])
# print(args[2])
# 
 infnm <- inputfilenm1
# for (i in seq(1:length(df_iofn$flno)))
# {
#   print(i)
#   infnm <- df_iofn$inf[i]
#   oufnm <- df_iofn$ouf[i]
# }

# Read the completed blast results into a table
#IDtable <- read.csv(file = args[1], sep='\t', header=F, as.is=TRUE)
IDtable <- read.csv(file = infnm, sep='\t', header=F, as.is=TRUE)

# Read the possible problematic TaxIDs as a table
MergedTaxIDs<-read.table("part06_MergedTaxIDs.txt", header=TRUE)

# Add header information, so the table is all nice and pretty
names(IDtable) <- c("qseqid","sseqid","pident","length",
                    "mismatch","gapopen","qstart","qend",
                    "sstart","send","evalue","bitscore",
                    "qlen","qcovs","sgi","sseq","ssciname","staxid")
# Extract only those rows where the qcovs score is 100
IDtable <- IDtable[IDtable$qcovs==100,]
#nrow(IDtable)
# Optionally make a smaller test table first, 
#to test if the script will run properly, e.g. just the first 100 rows:
# IDtable <- IDtable[1:100,]

IDtable_orig <- IDtable 
dim(IDtable_orig)
length(unique(IDtable_orig$staxid))
head(IDtable_orig,4)

IDtable_w600 <- IDtable_orig[1:600,]

#IDtable <- IDtable_w600

#Write the result to a table
#write.table(my_classified_result$classified_table, "my_classified_otus.txt", sep = "\t", quote = F, row.names = F)
#write.table(my_classified_result$classified_table, args[2], sep = "\t", quote = F, row.names = F)
#write.table(my_classified_result$classified_table, oufnm, sep = "\t", quote = F, row.names = F)

#}
# Explanation to input
#   INPUT.blasthits is the blast-results
#   upper_margin is the margin used for suboptimal hits used for classification - e.g. a margin of 0.5 means that hits of 100% to 99.5% is used og 95% to 94.5%, if the best hit is 100% or 95% respectively.
#   lower_margin: hits down to this margin from the best hit are shown in the output as alternative possibilities, but not used for taxonomic evaluation.
#   remove: a vector of taxa to exclude from the evaluation. Could be e.g. remove = c("uncultured","environmental") to exclude hits with no precise annotation, or names of species known not to be in the study area.
#
# Explanation to output
#   the output is a list with
#   $classified_table : the table with all OTUs classified. One row per OTU
#        this table contains the estimated best classification at all taxonomic levels, based on a weighted score (of the evalue) of the hits in the upper_margin, 
#        each taxonomic level gets a score indicating the agreement on the selected classification at that level..
#        also a string of alternatives and their matches (%) this string includes hits from both upper and lower margin
#   $all_classifications: this is the table used to make the classified_table. It contains all hits above lower_magrin for all OTUs and their classifications (only upper_margin).
#   ...and the input parameters
